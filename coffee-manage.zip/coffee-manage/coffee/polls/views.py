from django.shortcuts import render
import requests


# Create your views here.
def header(request):
    return render(request, 'header.html', {})



def main(request):
    return render(request, 'main.html', {})
def gioi_thieu(request):
    return render(request, 'gioi-thieu/gioi-thieu.html')
def khoi_nguon(request):
    return render(request,'gioi-thieu/khoi-nguon.html')
def dich_vu_khach_hang(request):
    return render(request,'gioi-thieu/dich-vu-khach-hang.html')
def nghe_nghiep(request):
    return render(request,'gioi-thieu/nghe-nghiep.html')


def tin_tuc(request):
    return render(request,'tin-tuc/tin-tuc.html')
def tin_tuc_su_kien(request):
    return render(request,'tin-tuc/tin-tuc-su-kien.html')
def tin_khuyen_mai(request):
    return render(request,'tin-tuc/tin-khuyen-mai.html')


def trach_nhiem_cong_dong(request):
    return render(request, 'trach-nhiem-cong-dong/trach-nhiem-cong-dong.html')
def cong_dong(request):
    return render(request,'trach-nhiem-cong-dong/cong-dong.html')
def gia_tri_van_hoa_viet(request):
    return render(request,'trach-nhiem-cong-dong/gia-tri-van-hoa-viet.html')


def thuc_don(request):
    return render(request,'thuc-don/thuc-don.html')

def ca_phe(request):
    return render(request,'thuc-don/ca-phe/ca-phe.html')
def ca_phe_phin(request):
    return render(request,'thuc-don/ca-phe/ca-phe-phin.html')
def phindi(request):
    return render(request,'thuc-don/ca-phe/phindi.html')
def ca_phe_espresso(request):
    return render(request,'thuc-don/ca-phe/ca-phe-espresso.html')

def freeze(request):
    return render(request,'thuc-don/freeze/freeze.html')
def freeze_ca_phe_phin(request):
    return render(request,'thuc-don/freeze/freeze-ca-phe-phin.html')
def freeze_khong_ca_phe(request):
    return render(request,'thuc-don/freeze/freeze-khong-ca-phe.html')

def tra(request):
    return render(request,'thuc-don/tra/tra.html')
def tra_sen_vang(request):
    return render(request,'thuc-don/tra/tra-sen-vang.html')
def tra_thach_dao(request):
    return render(request,'thuc-don/tra/tra-thach-dao.html')
def tra_thanh_dao(request):
    return render(request,'thuc-don/tra/tra-thanh-dao.html')
def tra_thach_vai(request):
    return render(request,'thuc-don/tra/tra-thach-vai.html')

def thit_nuong(request):
    return render(request,'thuc-don/banh-mi/thit-nuong.html')
def xiu_mai(request):
    return render(request,'thuc-don/banh-mi/xiu-mai.html')
def cha_lua_xa_xiu(request):
    return render(request,'thuc-don/banh-mi/cha-lua-xa-xiu.html')
def ga_xe_nuoc_tuong(request):
    return render(request,'thuc-don/banh-mi/ga-xe-nuoc-tuong.html')

def khac(request):
    return render(request,'thuc-don/khac/khac.html')
def banh_ngot(request):
    return render(request,'thuc-don/khac/banh-ngot.html')
def merchandise(request):
    return render(request,'thuc-don/khac/merchandise.html')
def ca_phe_dong_goi(request):
    return render(request,'thuc-don/khac/ca-phe-dong-goi.html')
def thuc_don_giao_hang(request):
    return render(request,'thuc-don/khac/thuc-don-giao-hang.html')

def tim_quan_ca_phe(request):
    return render(request,'quan-ca-phe/tim-quan-ca-phe.html')






# def main_page(request):
#     return render(request, "header.html")

# def output(request):
#     data = requests.get("https://reqres.in.api/users")
#     print(data.text)
#     data = data.text
#     return render(request, 'header.html', {'data': data})
