from django.db import models

# Create your models here.
from django.utils.translation import ugettext_lazy as _ #1

from django.utils.text import slugify #3
from datetime import date, datetime


class Coffe(models.Model):
    name = models.CharField(max_length=20)
    image = models.ImageField()
    price = models.CharField(max_length=100)
    status = models.CharField(max_length=20)

class Tintuc(models.Model):
    name = models.CharField(max_length=20)
    image = models.ImageField()
    date = models.DateTimeField(default= datetime.now)
    noidung = models.CharField(max_length=200)
