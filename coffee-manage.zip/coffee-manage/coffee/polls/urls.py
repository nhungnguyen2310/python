"""coffee URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [

    path('header.html', views.header, name="header"),
    path('main.html', views.main, name="main"),

    path('gioi-thieu/gioi-thieu.html', views.gioi_thieu, name="gioi-thieu"),
    path('gioi-thieu/khoi-nguon.html', views.khoi_nguon, name="khoi-nguon"),
    path('gioi-thieu/dich-vu-khach-hang.html', views.dich_vu_khach_hang, name="dich-vu-khach-hang"),
    path('gioi-thieu/nghe-nghiep.html', views.nghe_nghiep, name="nghe-nghiep"),


    path('tin-tuc/tin-tuc.html', views.tin_tuc, name="tin-tuc"),
    path('tin-tuc/tin-tuc-su-kien.html', views.tin_tuc_su_kien, name="tin-tuc-su-kien"),
    path('tin-tuc/tin-khuyen-mai.html', views.tin_khuyen_mai, name="tin-khuyen-mai"),


    path('trach-nhiem-cong-dong/trach-nhiem-cong-dong.html', views.trach_nhiem_cong_dong, name='trach-nhiem-cong-dong'),
    path('trach-nhiem-cong-dong/cong-dong.html', views.cong_dong, name="cong-dong"),
    path('trach-nhiem-cong-dong/gia-tri-van-hoa-viet.html', views.gia_tri_van_hoa_viet, name="gia-tri-van-hoa-viet"),


    path('thuc-don/thuc-don.html', views.thuc_don, name="thuc-don"),
    path('thuc-don/ca-phe/ca-phe.html', views.ca_phe, name='ca-phe'),
    path('thuc-don/ca-phe/ca-phe-phin.html', views.ca_phe_phin, name='ca-phe-phin'),
    path('thuc-don/ca-phe/phindi.html', views.phindi, name='phindi'),
    path('thuc-don/ca-phe/ca-phe-espresso.html', views.ca_phe_espresso, name='ca-phe-espresso'),

    path('thuc-don/freeze/freeze.html', views.freeze, name='freeze'),
    path('thuc-don/freeze/freeze-ca-phe-phin.html', views.freeze_ca_phe_phin, name='freeze-ca-phe-phin'),
    path('thuc-don/freeze/freeze-khong-ca-phe.html', views.freeze_khong_ca_phe, name='freeze-khong-ca-phe'),

    path('thuc-don/tra/tra.html', views.tra, name='tra'),
    path('thuc-don/tra/tra-sen-vang.html', views.tra_sen_vang, name='tra-sen-vang'),
    path('thuc-don/tra/tra-thach-dao.html', views.tra_thach_dao, name='tra-thach-dao'),
    path('thuc-don/tra/tra-thanh-dao.html', views.tra_thanh_dao, name='tra-thanh-dao'),
    path('thuc-don/tra/tra-thach-vai.html', views.tra_thach_vai, name='tra-thach-vai'),

    path('thuc-don/banh-mi/thit-nuong.html', views.thit_nuong, name='thit-nuong'),
    path('thuc-don/banh-mi/xiu-mai.html', views.xiu_mai, name='xiu-mai'),
    path('thuc-don/banh-mi/cha-lua-xa-xiu.html', views.cha_lua_xa_xiu, name='cha-lua-xa-xiu'),
    path('thuc-don/banh-mi/ga-xe-nuoc-tuong.html', views.ga_xe_nuoc_tuong, name='ga-xe-nuoc-tuong'),

    path('thuc-don/khac/khac.html', views.khac, name='khac'),
    path('thuc-don/khac/banh-ngot.html', views.banh_ngot, name='banh-ngot'),
    path('thuc-don/khac/merchandise.html', views.merchandise, name='merchandise'),
    path('thuc-don/khac/ca-phe-dong-goi.html', views.ca_phe_dong_goi, name='ca-phe-dong-goi'),
    path('thuc-don/khac/thuc-don-giao-hang.html', views.thuc_don_giao_hang, name='thuc-don-giao-hang'),

    path('quan-ca-phe/tim-quan-ca-phe.html', views.tim_quan_ca_phe, name='tim-quan-ca-phe'),
]
