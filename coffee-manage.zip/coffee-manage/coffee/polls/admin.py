from django.contrib import admin
from .models import Coffe
from .models import Tintuc
admin.site.register(Coffe)
admin.site.register(Tintuc)
# Register your models here.