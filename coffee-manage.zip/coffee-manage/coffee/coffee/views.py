from django.shortcuts import render
import requests


# Create your views here.
def header(request):
    return render(request, 'header.html', {})

def main(request):
    return render(request, 'main.html', {})
def gioi_thieu(request):
    return render(request, 'gioi-thieu/gioi-thieu.html')
def khoi_nguon(request):
    return render(request,'gioi-thieu/khoi-nguon.html')
def dich_vu_khach_hang(request):
    return render(request,'gioi-thieu/dich-vu-khach-hang.html')
def nghe_nghiep(request):
    return render(request,'gioi-thieu/nghe-nghiep.html')
def tin_tuc(request):
    return render(request,'tin-tuc/tin-tuc.html')


# def main_page(request):
#     return render(request, "header.html")

# def output(request):
#     data = requests.get("https://reqres.in.api/users")
#     print(data.text)
#     data = data.text
#     return render(request, 'header.html', {'data': data})
